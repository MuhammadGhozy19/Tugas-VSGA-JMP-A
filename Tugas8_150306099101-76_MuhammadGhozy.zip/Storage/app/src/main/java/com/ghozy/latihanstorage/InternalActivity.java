package com.ghozy.latihanstorage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class InternalActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String FILENAME = "FileInternal.text";
    Button buatFile, ubahFile, bacaFile, hapusFile, back;
    TextView textHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internal);
        buatFile = findViewById(R.id.btn_BuatFile);
        ubahFile = findViewById(R.id.btn_UbahFile);
        bacaFile = findViewById(R.id.btn_BacaFile);
        hapusFile = findViewById(R.id.btn_HapusFile);
        textHasil = findViewById(R.id.textHasil);
        back = findViewById(R.id.btn_back);

        buatFile.setOnClickListener(this);
        ubahFile.setOnClickListener(this);
        bacaFile.setOnClickListener(this);
        hapusFile.setOnClickListener(this);
        back.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        jalankanPerintah(v.getId());
    }

    public void jalankanPerintah(int id){
        switch (id){
            case R.id.btn_BuatFile:
                buatFile();
            break;
            case R.id.btn_UbahFile:
                ubahFile();
            break;
            case R.id.btn_BacaFile:
                bacaFile();
            break;
            case R.id.btn_HapusFile:
                hapusFile();
            break;
            case R.id.btn_back:
                Intent back = new Intent(InternalActivity.this, MainActivity.class);
                startActivity(back);
                break;
        }
    }

    void buatFile() {
        String isiFile = "Coba Isi Data File Text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, true);
            outputStream.write(isiFile.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    void ubahFile() {
        String ubah = "Update isi data file text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, false);
            outputStream.write(ubah.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    void bacaFile() {
        File fileInternal = getFilesDir();
        File file = new File(fileInternal, FILENAME);
        if (file.exists()){
            StringBuilder text = new StringBuilder();
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null){
                    text.append(line);
                    line = br.readLine();
                }
                br.close();
            }catch (IOException e){
                System.out.println("Error " + e.getMessage());
            }
            textHasil.setText(text.toString());
        }
    }

    void hapusFile(){
        File file = new File(getFilesDir(), FILENAME);
        if(file.exists()){
            file.delete();
        }
    }
}
