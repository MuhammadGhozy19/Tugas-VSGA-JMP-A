package com.ghozy.latihanstorage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;


public class ExternalActivity extends AppCompatActivity implements View.OnClickListener {
    private int EXTERNAL_STORAGE_PERMISSION_CODE = 23;
    public static final String FILENAME = "fileExternal.text";
    Button buatFile, ubahFile, bacaFile, hapusFile, back;
    TextView textHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_external);

        buatFile = findViewById(R.id.btn_BuatFile);
        ubahFile = findViewById(R.id.btn_UbahFile);
        bacaFile = findViewById(R.id.btn_BacaFile);
        hapusFile = findViewById(R.id.btn_HapusFile);
        textHasil = findViewById(R.id.textHasil);
        back = findViewById(R.id.btn_back);

        buatFile.setOnClickListener(this);
        ubahFile.setOnClickListener(this);
        bacaFile.setOnClickListener(this);
        hapusFile.setOnClickListener(this);
        back.setOnClickListener(this);
    }
    @Override
    public void onClick(View v){
        jalankanPerintah(v.getId());
    }

    public void jalankanPerintah(int id){
        switch (id){
            case R.id.btn_BuatFile:
                buatFile();
                break;
            case R.id.btn_UbahFile:
                ubahFile();
                break;
            case R.id.btn_BacaFile:
                bacaFile();
                break;
            case R.id.btn_HapusFile:
                hapusFile();
                break;
            case R.id.btn_back:
                Intent back = new Intent(ExternalActivity.this, MainActivity.class);
                startActivity(back);
                break;
        }
    }

    void buatFile() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                EXTERNAL_STORAGE_PERMISSION_CODE);
        String isiFile = "Coba Isi Data File Text";
        String state = Environment.getExternalStorageState();
        if(!Environment.MEDIA_MOUNTED.equals(state)){
            return;
        }
        File Folder = getExternalFilesDir("Latihan Stroage");
        File file = new File(Folder, FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, true);
            outputStream.write(isiFile.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    void ubahFile() {
        String ubah = "Update isi data file text";
        String state = Environment.getExternalStorageState();
        if(!Environment.MEDIA_MOUNTED.equals(state)){
            return;
        }

        File Folder = getExternalFilesDir("Latihan Stroage");
        File file = new File(Folder, FILENAME);

        FileOutputStream outputStream = null;
        try {
            file.createNewFile();
            outputStream = new FileOutputStream(file, false);
            outputStream.write(ubah.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    void bacaFile() {
        File Folder = getExternalFilesDir("Latihan Stroage");
        File file = new File(Folder, FILENAME);
        if (file.exists()){
            StringBuilder text = new StringBuilder();
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();
                while (line != null){
                    text.append(line);
                    line = br.readLine();
                }
                br.close();
            }catch (IOException e){
                System.out.println("Error " + e.getMessage());
            }
            textHasil.setText(text.toString());
        }
    }

    void hapusFile(){
        File Folder = getExternalFilesDir("Latihan Stroage");
        File file = new File(Folder, FILENAME);
        if(file.exists()){
            file.delete();
        }
    }
}
