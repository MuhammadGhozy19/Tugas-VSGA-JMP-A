package com.ghozy.latihanstorage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn_intStr, btn_extStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_intStr = findViewById(R.id.btn_intStr);
        btn_extStr = findViewById(R.id.btn_extStr);
        btn_intStr.setOnClickListener(this);
        btn_extStr.setOnClickListener(this);
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_intStr:
                Intent internal = new Intent(   MainActivity.this, InternalActivity.class);
                startActivity(internal);
                break;
            case R.id.btn_extStr:
                Intent external = new Intent(MainActivity.this, ExternalActivity.class);
                startActivity(external);
                break;
        }
    }
}
